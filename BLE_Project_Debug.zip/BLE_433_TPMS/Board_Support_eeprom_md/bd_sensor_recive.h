
#ifndef __BD_SENSOR_RECIVE_H
#define __BD_SENSOR_RECIVE_H

/* Includes */
#include "stdint.h"
#include <stdbool.h>
//#include "buffer.h"

#define RF_IRQ_PIN_NUMBER 13 //
#define RF_DECODE_PIN_NUMBER 12 //new:12  old:11  ***

#define RF_DECODE_ENABLE()	nrf_gpio_pin_set(RF_DECODE_PIN_NUMBER)
#define RF_DECODE_DISABLE()	nrf_gpio_pin_clear(RF_DECODE_PIN_NUMBER)

#define I2C_SLAVE_MCU_ADDR 0X6C

#define FIFO_DATA_PACKET	6
#define FIFO_DATA_PACKET_NUM	22
#define FIFO_MAX_SIZE	  (42*6) //(FIFO_DATA_PACKET*FIFO_DATA_PACKET_NUM*2)

#define T_LEVEL1_VALUE	75
#define T_LEVEL2_VALUE	85

typedef enum
{
  LEAK_NORMAL=0,
  LEAK_SLOW,
  LEAK_FAST,
}LEAK;

typedef enum 
{
	SENSOR_RUN_INIT=0,
	NO_CLEAN_MORE_50KPA_5TIMES=1,
	NO_CLEAN_LOW_NOS=2,
	SENSOR_NOS=4,
	SENSOR_PROBLEM=8,//BROKEN OR REMOVE;
}SENSOR_STEP_TYPE;

typedef union 
{    
  struct
  {
	unsigned bSensorClean     	:1;	
	unsigned bLeakStaturs	   	:2;
	unsigned bLearn_sign	   	:1; 
  unsigned step_status        :4;
  }bits;
  uint8_t value;
}SENSOR_STATUS_Type;

typedef union 
{    
  struct
  {
    unsigned bLearn_sign		:2;
    unsigned bConnect			:2;
    unsigned bMsc_status		:2;
    unsigned bLeakStaturs	   	:2;
  }bits;
  uint8_t value;
  /*bit:0~1:学习过，未学习过；
  bit：2~3 ：00:connect 11:disconnect;断开或连接；
  bit：4~5：normal，nos，lowpower；
  bit：6~7：泄漏，快慢
  */
}SEND_TO_CLOUD_Type;


typedef struct 
{
	SEND_TO_CLOUD_Type send_status;
	SENSOR_STATUS_Type status;		//1byte              
	uint32_t sensor_id; 		    //3byte
	uint8_t temperature; 			//1byte 
	uint16_t get_pressure;			//2byte
	uint16_t set_pressure;      	//2byte
     
	uint16_t step_time;
	uint8_t bExceptionAction  :1;
	uint8_t bException        :1;
//	uint8_t nos_wake_times;  
}SENSOR_DATA_Type;

void sensor_recive_init(void);
void read_fifo_check_handle(void);
void save_data_to_flash(void);
void get_sensor_level_status(uint8_t num);
void cmp_sensor_data(uint8_t *current_data);

/**
  * @}
  */

#endif /* __RF_DECODE_H*/
