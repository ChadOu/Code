
#ifndef __BD_COM_PROTOCOL_H
#define __BD_COM_PROTOCOL_H

#include "stdint.h"
#include <stdbool.h>

	#define FUNC_SYNC_CMD    	0x02
	#define FUNC_LEARN_CMD    	0x04
	#define FUNC_CHAOSHI_CMD  	0x0c
	#define FUNC_DELETE_CMD   	0x06
	#define FUNC_SETUP_CMD    	0x0a
	#define FUNC_CLEARN_CMD   	0x0d
	#define FUNC_CUT_REAR_CMD   0x08

void send_to_ble(void);
void rec_command(uint8_t *pdata);

#endif
