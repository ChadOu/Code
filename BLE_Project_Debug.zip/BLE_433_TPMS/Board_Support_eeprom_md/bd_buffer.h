#ifndef __BD_BUFFER_H
#define __BD_BUFFER_H

/* Includes ------------------------------------------------------------------------------------------------*/
#include "stdint.h"
#include "stdbool.h"

/* Exported types ------------------------------------------------------------------------------------------*/
/**
 * @brief  Operation information for I2C buffer
 */
typedef struct
{
  uint8_t uRead;
  uint8_t uWrite;
  uint8_t *puMemory;
  uint8_t uSize;
} Buffer_TypeDef;

/* Exported constants --------------------------------------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------------------------------------*/
/* Exported variables --------------------------------------------------------------------------------------*/
/* Exported functions --------------------------------------------------------------------------------------*/
void buffer_init(Buffer_TypeDef *pBuffer, uint8_t *puMemory, uint8_t uSize);

bool buffer_read(Buffer_TypeDef *pBuffer, uint8_t *puData, uint8_t uLength);
bool buffer_write(Buffer_TypeDef *pBuffer, uint8_t *puData, uint8_t uLength);



#endif 
