/**
 * @file     ble51822 board.c
 * @version  SDK:6.0.0;	SoftDevice:s110_nrf51822_7.0.0
 * @Compiler Armcc.exe v5.03.076(Evaluation) 
 * @IDE			 uVisionV4.72.0.0
 * @author	 Sam
 * @date     21/09/2015(First)
 * @brief   
 *
 **/
/* Includes*/
#include "bd_twi_master.h"
#include "bd_sensor_recive.h"
#include "nrf_gpio.h"
#include <nrf.h>
#include "nrf_delay.h"
#include "app_timer.h"
#include "bd_uart_debug.h"
#include "app_util_platform.h"
#include "bd_buffer.h"
#include <string.h>
#include "bd_data_manager.h"
#include "bd_com_protocol.h"
#include "bd_system_state_machine.h"


SENSOR_DATA_Type gSensor[22];
SYSTEM_TypeDef gSystem;
Buffer_TypeDef pBuffer;	
uint8_t cmp_buffer[FLASH_OP_MAX];
uint8_t sensor_buffer[FIFO_MAX_SIZE];
/*
 *  Function: WriteSensorData;
 *  Parameters:1~22
 *  Returns: 
 *  Description:
 */
void update_sensor_data(uint8_t num,uint8_t *offset,DATA_SAVE_TYPE *op_data_t)
{
	uint8_t *poffset;
	poffset=offset;
	op_data_t->arry[(*poffset)++]=gSensor[num].sensor_id>>16;  
	op_data_t->arry[(*poffset)++]=gSensor[num].sensor_id>>8;  
	op_data_t->arry[(*poffset)++]=gSensor[num].sensor_id;
	op_data_t->arry[(*poffset)++]=gSensor[num].get_pressure>>8;
	op_data_t->arry[(*poffset)++]=gSensor[num].get_pressure;
	op_data_t->arry[(*poffset)++]=gSensor[num].set_pressure>>8;
	op_data_t->arry[(*poffset)++]=gSensor[num].set_pressure;
	op_data_t->arry[(*poffset)++]=gSensor[num].temperature;  
	op_data_t->arry[(*poffset)++]=gSensor[num].status.value;
}

static bool bEeprom_data;
void cmp_sensor_data(uint8_t *current_data)
{
	uint8_t i;
	for(i=FLASH_OP_MAX-2;i;)
	{
		i--;
		if(cmp_buffer[i]!=current_data[i])
		{
			bEeprom_data=true;
			cmp_buffer[i]=current_data[i];
		}
	}	
}
/*
 *  Function: WriteSensorData;
 *  Parameters:1~22
 *  Returns: 
 *  Description:
 */
void save_data_to_flash(void)
{
	uint8_t num,temp_offset;
	uint16_t temp_u16;
	DATA_SAVE_TYPE op_data_t;
	temp_offset=2;
	temp_u16=FIRST_OP_EEPROM_CONST;
	op_data_t.arry[0]=temp_u16;
	op_data_t.arry[1]=temp_u16>>8;
	for(num=22;num;)
	{
		num--;
		update_sensor_data(num,&temp_offset,&op_data_t);
	}
	op_data_t.arry[FLASH_OP_MAX-3]=gSystem.monitor_car_node;	
	op_data_t.arry[FLASH_OP_MAX-2]=gSystem.monitor_tail;
	op_data_t.arry[FLASH_OP_MAX-1]=gSystem.monitor_head;
	bEeprom_data=false;
	cmp_sensor_data(op_data_t.arry);
	if(bEeprom_data==true)
	{
		op_data_t.op_offset=0;
		op_data_t.op_size=FLASH_OP_MAX;	
		user_data_store(&op_data_t);
	}		
}
/*
 *  Function:
 *  Parameters:
 *  Returns: 
 *  Description:
 */
void get_sensor_level_status(uint8_t num)
{
  static bool bResult;
  bResult=0;
  /*pressure*/
  if(gSensor[num].get_pressure<(gSensor[num].set_pressure/2))
  {
/*  	 if(!((gSensor[num].get_pressure<50)&&(gSensor[num].status.bits.bLeakStaturs==0)))
      {
        bResult=1;      
      } */
/*      if(gSensor[num].get_pressure>49)
      {
        bResult=1;
      }*/
    bResult=1;
  }
  else if(gSensor[num].get_pressure<=(gSensor[num].set_pressure*3/4))
  {
    bResult=1;
  }
  else if(gSensor[num].get_pressure<=(gSensor[num].set_pressure*17/20))
  {
    bResult=1;    
  }
  else if(gSensor[num].get_pressure>(gSensor[num].set_pressure*5/4))
  {
    bResult=1; 
  }
  /*temperature*/
  if(gSensor[num].temperature>T_LEVEL2_VALUE)
  {
    bResult=1;
  }
  else if(gSensor[num].temperature>T_LEVEL1_VALUE)
  {
    bResult=1;
  }
  /*leak*/
  if(gSensor[num].status.bits.bLeakStaturs==LEAK_SLOW)
  {
    bResult=1;
  }
  else if(gSensor[num].status.bits.bLeakStaturs==LEAK_FAST)
  {   
    bResult=1; 
  }
  /*spection case*/
  if(gSensor[num].status.bits.step_status&0x0e)
  {
    bResult=1;
  }
  /*adj exception status*/
  if(bResult)
  {
    if(gSensor[num].bException==0)
    {
      gSensor[num].bExceptionAction=1;
    }       
    gSensor[num].bException=1; 
  }
  else
  {
      gSensor[num].bExceptionAction=0;
      gSensor[num].bException=0;
  }
}
/**
  * @brief 
  * @param 
  * @retval
  */
void read_fifo_check_handle(void)
{
	uint8_t out_arry[FIFO_DATA_PACKET],num,temp_tire,u8_temp;
	uint32_t temp_id;
	bool bMach,bFix_ok,bMach_temp;
	
	if(buffer_read(&pBuffer,out_arry,FIFO_DATA_PACKET)==true)
	{
	  /*id adj*/
		gSystem.bDebug_rx_twi=!gSystem.bDebug_rx_twi;
		LOG(LEVEL_INFO,"tire pressure :%d kPa",out_arry[3]);	
		temp_id=out_arry[0];//idh;
		temp_id<<=8; 
		temp_id|=out_arry[1];//idm;
		temp_id<<=8;
		temp_id|=out_arry[2];//idm;	
		bMach=false;
		bMach_temp=false;				
        for(num=0;num<22;num++)
        {
          if(temp_id==gSensor[num].sensor_id)
          {
            if(gSensor[num].status.bits.bLearn_sign==true)
            {
				bMach_temp=true;
				if((num<gSystem.monitor_tail)&&(num>=gSystem.monitor_head))
				{
					bMach=true;
					temp_tire=num;
					break;
				}
            }	
          }
        }		
		
		bFix_ok=false;
        u8_temp=out_arry[5]&0x03;				
        if(bMach_temp==false)
        {            
            if(u8_temp==0x03)//learn flag;
            {
            	num=gSystem.learnNum-1;//change num;
                if(gSystem.learnNum)
                {
                    if(gSensor[num].status.bits.bLearn_sign==false)
                    {
                    	gSensor[num].status.bits.bLearn_sign=true;
                    	gSensor[num].send_status.bits.bLearn_sign=1;
                        gSensor[num].sensor_id=temp_id;                             
                        temp_tire=num;
                        //gSystem.buzzer_model=BUZZER_BI_ONCE;
                        bFix_ok=true;
                    }					
                }
            }
        }
		/*adj load data*/
		if(bMach||bFix_ok)
		{		
			/*update related tire status*/
			//gSystem.bUpdate_data=1;
			gSensor[temp_tire].step_time=0;
			//gSensor[temp_tire].nos_wake_times=0;
			gSensor[temp_tire].status.bits.bSensorClean=0;
			gSensor[temp_tire].status.bits.step_status=SENSOR_RUN_INIT;
			/*temperture*/
			gSensor[temp_tire].temperature=out_arry[4];
			/*Pressure*/
			gSensor[temp_tire].get_pressure=out_arry[5]&0x70;
			gSensor[temp_tire].get_pressure<<=4;
			gSensor[temp_tire].get_pressure|=out_arry[3];
			/*staturs*/
			if(u8_temp!=0x03)
			{
			 	gSensor[temp_tire].status.bits.bLeakStaturs=u8_temp; 
			 	gSensor[temp_tire].send_status.bits.bLeakStaturs=u8_temp; 
			}
			else
			{
				gSensor[temp_tire].send_status.bits.bLeakStaturs=0; 
				gSensor[temp_tire].status.bits.bLeakStaturs=0;
			}
			get_sensor_level_status(temp_tire);//set fix over compare   
			/*send to cloud*/
			gSystem.send_cmd=CMD_UPDATE;
			gSystem.bSend=1;
			gSystem.update_tire=temp_tire;
		}			
	}	
}
/**
  * @brief 
  * @param 
  * @retval
  */	
void sensor_recive_init(void)
{
	//uint32_t err_code;
	/*init i2c master*/
	if(twi_master_init()!=true)
	{
		LOG(LEVEL_INFO,"twi_master_init ERROR");
	}
	else
	{
		LOG(LEVEL_INFO,"twi_master_init OK");
	}
	/*config rf gpio*/
	nrf_gpio_cfg_input(RF_IRQ_PIN_NUMBER,NRF_GPIO_PIN_NOPULL);
	nrf_gpio_cfg_output(RF_DECODE_PIN_NUMBER);
	/*config gpiote*/
	{
		uint32_t final_config;		
		NRF_GPIOTE->CONFIG[1] &= ~(GPIOTE_CONFIG_PSEL_Msk | GPIOTE_CONFIG_POLARITY_Msk);
		NRF_GPIOTE->CONFIG[1] |= ((RF_IRQ_PIN_NUMBER << GPIOTE_CONFIG_PSEL_Pos) & GPIOTE_CONFIG_PSEL_Msk) |
															((GPIOTE_CONFIG_POLARITY_LoToHi << GPIOTE_CONFIG_POLARITY_Pos) & GPIOTE_CONFIG_POLARITY_Msk);	
		final_config = NRF_GPIOTE->CONFIG[1] | GPIOTE_CONFIG_MODE_Event;
		NRF_GPIOTE->CONFIG[1] = final_config | ((31 << GPIOTE_CONFIG_PSEL_Pos) & GPIOTE_CONFIG_PSEL_Msk);
		__NOP();
		__NOP();
		__NOP();
		NRF_GPIOTE->CONFIG[1] = final_config;
		NRF_GPIOTE->INTENSET = GPIOTE_INTENSET_IN1_Msk;	
		NRF_GPIOTE->EVENTS_IN[1]=0;
		NVIC_SetPriority(GPIOTE_IRQn, APP_IRQ_PRIORITY_HIGH);//GPIOTE_CONFIG_IRQ_PRIORITY
		NVIC_ClearPendingIRQ(GPIOTE_IRQn);
		NVIC_EnableIRQ(GPIOTE_IRQn);
	}
	/*init rf enable*/
	RF_DECODE_ENABLE();//433 Decode+LNA
	/*register handler*/
	memset(sensor_buffer,0,sizeof(uint8_t)*FIFO_MAX_SIZE);
	buffer_init(&pBuffer,sensor_buffer,FIFO_MAX_SIZE);
}	
/**
  * @brief 
  * @param 
  * @retval
  */
void GPIOTE_IRQHandler(void)
{
	//uint32_t status = 0;
	uint8_t recive_data[6];
  	if(NRF_GPIOTE->EVENTS_IN[1])
	{
		NRF_GPIOTE->EVENTS_IN[1]=0;		
	  	twi_master_transfer(I2C_SLAVE_MCU_ADDR|TWI_READ_BIT,recive_data,6,TWI_ISSUE_STOP);
		if(recive_data[0]||recive_data[1]||recive_data[2]||recive_data[3])
		{
			buffer_write(&pBuffer, recive_data,FIFO_DATA_PACKET);	
		}
	}
}
