
#include "bd_system_state_machine.h"
#include "ble_user_srv.h"
#include "bd_led_flash.h"
#include "bd_buzzer.h"
#include "bd_com_protocol.h"
#include "bd_battery.h"
#include "bd_sensor_recive.h"  
#include "bd_button.h"  
#include "bd_uart_debug.h"
#include "bd_vibration_switch.h"
#include "bd_data_manager.h"
#include "bd_com_protocol.h"
#include "nrf_soc.h"
#include <string.h>
#include "nrf_delay.h"

void system_normal_state(void);
void system_sleep_state(void);
void system_idle_state(void);

extern SENSOR_DATA_Type gSensor[22];
extern SYSTEM_TypeDef gSystem;
app_timer_id_t    m_global_timer_id;  
//static uint8_t test_delay=0;
static uint8_t loop_time=10;
/**@brief Function for starting timers.
*/
void application_timers_start(void)
{
	vibration_switch_timer_start();
	battery_measure_timer_start();
	button_detect_timer_start();
	app_timer_start(m_global_timer_id, APP_TIMER_TICKS(100, APP_TIMER_PRESCALER), NULL);
}

/**@brief Function for stop timers.
*/
void application_timers_stop(void)
{
	battery_measure_timer_stop();
	vibration_switch_timer_stop();
	button_detect_timer_stop();
	app_timer_stop(m_global_timer_id);
}
/*
*/
void wakeup_cfg(void)
{
	gSystem.model=M_GOTO_SLEEP;
	buzzer_control(BUZZER_BI_TWICE);
	nrf_gpio_cfg_sense_set(BUTTON_POWER_PIN_NUMBER,NRF_GPIO_PIN_SENSE_LOW);
}

/** button_event_handler;
 */
bool bButton_sleep=false;
void button_event_handler(button_event_t event)
{
	//uint32_t err_code;
	switch(event)
	{
		case BUTTON_EVENT_PRESS:
			LOG(LEVEL_INFO,"button press ok!");
			gSystem.sensor.bBuzzer_done=true;
		break;
		case BUTTON_EVENT_SLEEP:
			bButton_sleep=true;			
			LOG(LEVEL_INFO,"begin go to sleep!");
		break;
		case BUTTON_EVENT_RELEASE:
			LOG(LEVEL_INFO,"button release ok!");
			if(bButton_sleep==true)
			{
				bButton_sleep=false;
				wakeup_cfg();
			}
			break;
		default:
			break;
	}
}
/*
 *  Function: 
 *  Parameters:
 *  Returns: 
 *  Description:
 */
void check_sensor_nos(uint8_t num)
{
  if(gSensor[num].status.bits.bSensorClean==true)
  {
    if(gSensor[num].status.bits.step_status==SENSOR_RUN_INIT)
    {
      if(gSensor[num].step_time>(20*60))//(20*60)
      {
        gSensor[num].step_time=0;
        gSensor[num].status.bits.step_status=SENSOR_NOS;

        gSensor[num].bException=true;
        gSensor[num].bExceptionAction=true;
      }
      else
      {
        gSensor[num].step_time++;
      }
    }
    else if(gSensor[num].status.bits.step_status==SENSOR_NOS)
    {
      if(gSensor[num].step_time>(60*60))//(60*60)
      {
        gSensor[num].step_time=0;
        gSensor[num].status.bits.step_status=SENSOR_PROBLEM;
        gSensor[num].bException=true;
        gSensor[num].bExceptionAction=true;
      }
      else
      {
        gSensor[num].step_time++;
      }
    }
  }
  else
  {
    if(gSensor[num].status.bits.step_status==SENSOR_RUN_INIT)
    {
      if(gSensor[num].get_pressure<50)
      {             
        if(gSensor[num].step_time>(5*60))//5 minute 5*60
        {
          gSensor[num].step_time=0;
          gSensor[num].status.bits.step_status=NO_CLEAN_LOW_NOS;
          gSensor[num].bException=1;
          gSensor[num].bExceptionAction=1;
        }
        else
        {
          gSensor[num].step_time++;
        }
      }
      else
      {
	      if(gSensor[num].step_time>(60*60))//(60*60)
	      {
	        gSensor[num].step_time=0;
	        gSensor[num].status.bits.step_status=SENSOR_NOS;
	        gSensor[num].bException=true;
	        gSensor[num].bExceptionAction=true;
	      }
	      else 
	      {
	        gSensor[num].step_time++;
	      }
      } 
    }
    else if(gSensor[num].status.bits.step_status==SENSOR_NOS)
    {
      if(gSensor[num].step_time>(60*60))//(60*60)
      {
        gSensor[num].step_time=0;
        gSensor[num].status.bits.step_status=SENSOR_PROBLEM;
        gSensor[num].bException=true;
        gSensor[num].bExceptionAction=true;
      }
      else
      {
        gSensor[num].step_time++;
      }
    }
  }
  if(gSensor[num].status.bits.step_status&0x0e)
  {
  	if(gSensor[num].send_status.bits.bMsc_status==0)
  	{
  		gSystem.send_cmd=CMD_UPDATE;
		gSystem.bSend=1;
		gSystem.update_tire=num;
		gSensor[num].send_status.bits.bMsc_status=1; 
  	}  	 	
  } 
  else
  {
  	gSensor[num].send_status.bits.bMsc_status=0;
  }
  /*warning loop*/
  if(gSensor[num].status.bits.step_status==SENSOR_PROBLEM)
  {
    if(gSensor[num].step_time>(60*60))//(60*60)
    {
      gSensor[num].step_time=0;
      gSensor[num].bException=true;
      gSensor[num].bExceptionAction=true;
    }
    else
    {
      gSensor[num].step_time++;
    }
  }
}
/*
 *  Function: 
 *  Parameters:
 *  Returns: 
 *  Description:
 */
static bool temp_exception;
static bool temp_exception_action;
void multi_warning_to_one(uint8_t num)
{
    if(gSensor[num].status.bits.step_status&0x0e)
    {
      if(gSensor[num].bException==0)
      {
        gSensor[num].bExceptionAction=1;
      }
      gSensor[num].bException=1;
    }
    //red blink signal;
    if(gSensor[num].bException) 
    {
      temp_exception=true;
    }
    if((gSensor[num].bExceptionAction)&&(gSystem.model==M_NORMAL))
    {         
      //LOG(LEVEL_INFO,"gSensor[num].status.bits.step_status:%d",gSensor[num].status.bits.step_status);
      gSensor[num].bExceptionAction=0;
      temp_exception_action=true;
    }
}
/*
 *  Function: 
 *  Parameters:
 *  Returns:
 *  Description:
 */
void lean_sensor_data_clean(uint8_t num)
{
  gSensor[num].status.value=0; 
  gSensor[num].send_status.value=0; 
  gSensor[num].bException=0;
  gSensor[num].bExceptionAction=0;                     
  gSensor[num].get_pressure=0;
  gSensor[num].temperature=0;  
  gSensor[num].step_time=0;                                    
//  gSensor[num].nos_wake_times=0;
}
/*
 *  Function: 
 *  Parameters:
 *  Returns:
 *  Description:
 */
void remove_sensor_data(uint8_t num)
{
	gSensor[num].send_status.value=0;
	gSensor[num].sensor_id=0;
	gSensor[num].status.value=0;
	gSensor[num].bException=0;
	gSensor[num].bExceptionAction=0;
//	gSensor[num].nos_wake_times=0;
	gSensor[num].step_time=0;
}
/*
 *  Function: 
 *  Parameters:
 *  Returns:
 *  Description:
 */
void monitor_tire_status(MONITOR_TIRE_ENUM m_status)
{
  uint8_t num;
  for(num=gSystem.monitor_head;num<gSystem.monitor_tail;num++)
  {       
    if(gSensor[num].status.bits.bLearn_sign==true)
    {
      switch(m_status)
      {
        case MONITOR_ALARM:
        {
          multi_warning_to_one(num);
        }break;
        case MONITOR_NOS:
        {
          check_sensor_nos(num);
        }break;
        case MONITOR_CLEAN_NOS_TIME:
        {
          gSensor[num].step_time=0;
        }break;
        case MONITOR_GET_LEVEL:
        {
          get_sensor_level_status(num);
        }break;
        case MONITOR_REMOVE_SENSOR:
        {
          remove_sensor_data(num);
        }break;
        case MONITOR_CLEAN_SENSOR:
        {  
          lean_sensor_data_clean(num);
          gSensor[num].status.bits.bLearn_sign=1; 
          gSensor[num].send_status.bits.bLearn_sign=1;  
          gSensor[num].status.bits.bSensorClean=1;//spection          
        }break;
        default:break;
      }
    }       
  }
}
#define DEBUG_DISPLAY  1
/*
*/
void led_control_status(void)
{
	if(gSystem.bConnect_status!=gSystem.bConnect_status_back)
	{
		gSystem.bConnect_status_back=gSystem.bConnect_status;
		if(gSystem.bConnect_status==true)
		{
			leds_control(T_BLUE_LED,LED_BLINK_FAST);
		}
		else/*power status led display*/
		{
			leds_control(T_BLUE_LED,LED_ON);
		}
	}
	if(gSystem.bException!=gSystem.bException_back)
	{
		gSystem.bException_back=gSystem.bException;
		if(gSystem.bException==true)
		{			
			leds_control(T_RED_LED,LED_BLINK_FAST);
		}
		else
		{
			leds_control(T_RED_LED,LED_OFF);
		}
	}
	#ifndef DEBUG_DISPLAY
	if(gSystem.bLow_power!=gSystem.bLow_power_back)
	{
		gSystem.bLow_power_back=gSystem.bLow_power;
		if(gSystem.bLow_power==true)
		{			
			leds_control(T_YELLOW_LED,LED_BLINK_FAST);
		}
		else
		{
			leds_control(T_YELLOW_LED,LED_OFF);
		}
	}
	#else
	if(gSystem.bDebug_rx_twi!=gSystem.bDebug_rx_twi_back)
	{
		if(gSystem.bDebug_rx_twi==true)
		{
			leds_control(T_YELLOW_LED,LED_ON);
		}
		else
		{
			leds_control(T_YELLOW_LED,LED_OFF);
		}
		gSystem.bDebug_rx_twi_back=gSystem.bDebug_rx_twi;
	}
	#endif
}
/**@brief Function for stop timers.
*/
static uint8_t sync_space_delay=0;
uint16_t test_delayxx;
static void system_timeout_handler(void* p_context)
{
	uint32_t err_code;
	if(gSystem.bSync_send_done==true)
	{
		sync_space_delay++;
		if(sync_space_delay>10)
		{
			gSystem.bSync_send_done=false;
			gSystem.bSync_space_ok=true;
			sync_space_delay=0;
		}
	}
	/*loop count delay*/
	if(gSystem.model==M_NORMAL)
	{
		read_fifo_check_handle();
		if(loop_time==0)
		{
			loop_time=10;
			if(gSystem.learnTimeOut==0)
			{ 
				gSystem.learnNum=0;
			}
			else
			{
				gSystem.learnTimeOut--;
			}
			vibration_detect_handler();
			monitor_tire_status(MONITOR_NOS);
			temp_exception=false;
			temp_exception_action=false;
			monitor_tire_status(MONITOR_ALARM);
			if(temp_exception_action==true)
			{
				buzzer_control(BUZZER_BI_ALARM);
			}
			if(temp_exception==true)
			{
				gSystem.bException=1;
			}
			else
			{
				if(gSystem.bException==true)
				{
					buzzer_control(BUZZER_INIT);
					gSystem.bException=false;
				}
			}
		}
		else
		{
			loop_time--;
		}				
	}
	else
	{
		if(gSystem.model==M_GOTO_SLEEP)
		{
			if(gSystem.sensor.bBuzzer_done==true)
			{
				gSystem.bSave=true; 
			    gSystem.bSave_done=false;
				gSystem.model=M_SLEEP;
			}
		}
		else if(gSystem.model==M_SLEEP)
		{			
		    if(gSystem.bSave_done==true)
		    {
			    application_timers_stop();
			    RF_DECODE_DISABLE();
			    nrf_gpio_pin_clear(LED_YELLOW_PIN_NUMBER);
			    nrf_gpio_pin_clear(LED_RED_PIN_NUMBER);
			    nrf_gpio_pin_clear(LED_BLUE_PIN_NUMBER);
			    LOG(LEVEL_INFO,"sleep!");
			    // Go to system-off mode (this function will not return; wakeup will cause a reset).
			    err_code = sd_power_system_off();
			    APP_ERROR_CHECK(err_code);	
		    }
		}	    
	}
	led_control_status();//led control	      
}
/** init primary just config each modle;
 */
static void init_primary(void)
{
	//uint32_t err_code;
  button_init(APP_TIMER_TICKS(10, APP_TIMER_PRESCALER),button_event_handler);
	LOG(LEVEL_INFO,"button init ok!");
	leds_init(APP_TIMER_TICKS(100, APP_TIMER_PRESCALER));		
	LOG(LEVEL_INFO,"leds init ok!");
  buzzer_init(APP_TIMER_TICKS(50, APP_TIMER_PRESCALER));
	LOG(LEVEL_INFO,"buzzer init ok!");
  vibration_switch_init(APP_TIMER_TICKS(2, APP_TIMER_PRESCALER));
	LOG(LEVEL_INFO,"vibration init ok!");
	battery_init(APP_TIMER_TICKS(1000, APP_TIMER_PRESCALER));
	LOG(LEVEL_INFO,"battery init ok!");
  sensor_recive_init();	
	LOG(LEVEL_INFO,"sensor init ok!");
}
/**@brief Function for the IO init.
 */
static void io_init(void)
{
	uint8_t i;
	/*IO pin init*/
	for(i = 0; i< 32 ; ++i )
	{
		NRF_GPIO->PIN_CNF[i] = (GPIO_PIN_CNF_SENSE_Disabled << GPIO_PIN_CNF_SENSE_Pos)
							 | (GPIO_PIN_CNF_DRIVE_S0S1 << GPIO_PIN_CNF_DRIVE_Pos)
							 | (GPIO_PIN_CNF_PULL_Disabled << GPIO_PIN_CNF_PULL_Pos)
							 | (GPIO_PIN_CNF_INPUT_Disconnect << GPIO_PIN_CNF_INPUT_Pos)
							 | (GPIO_PIN_CNF_DIR_Input << GPIO_PIN_CNF_DIR_Pos);
	}   
}
/** bsp system off;
 */
void power_system_off()
{
    nrf_gpio_cfg_sense_input(BAT_DETECT_PIN_NUMBER,NRF_GPIO_PIN_NOPULL,NRF_GPIO_PIN_SENSE_LOW);    
    //enter system off
    NRF_POWER->SYSTEMOFF = POWER_SYSTEMOFF_SYSTEMOFF_Enter;
}
/** system idle state;
 */
void system_idle_state(void)
{
	//uint32_t erro_code;
	DATA_SAVE_TYPE op_data_t;
	uint16_t u16temp;	
	uint8_t tempTire,cnt,num;
	/**/
	//pstorage_user_data_init();
	op_data_t.op_offset=0;
	op_data_t.op_size=FLASH_OP_MAX;
	read_flash_data_out(&op_data_t);
	u16temp=op_data_t.arry[1];
	u16temp<<=8;
	u16temp|=op_data_t.arry[0];
	cnt=2;
	if(u16temp==FIRST_OP_EEPROM_CONST)
	{
		for(tempTire=22;tempTire;)
		{		
			tempTire--;
			gSensor[tempTire].sensor_id=(op_data_t.arry[cnt++])<<16; 
			gSensor[tempTire].sensor_id|=(op_data_t.arry[cnt++])<<8; 
			gSensor[tempTire].sensor_id|=op_data_t.arry[cnt++]; 
			gSensor[tempTire].get_pressure=(op_data_t.arry[cnt++]<<8);
			gSensor[tempTire].get_pressure|=op_data_t.arry[cnt++];

			gSensor[tempTire].set_pressure=(op_data_t.arry[cnt++])<<8;//defalut set pressure; 
			gSensor[tempTire].set_pressure|=op_data_t.arry[cnt++];//defalut set pressure;
			
			gSensor[tempTire].temperature=op_data_t.arry[cnt++];				
			gSensor[tempTire].status.value=op_data_t.arry[cnt++];
			gSensor[tempTire].send_status.bits.bLearn_sign=gSensor[tempTire].status.bits.bLearn_sign;
			gSensor[tempTire].send_status.bits.bLeakStaturs=gSensor[tempTire].status.bits.bLeakStaturs;
			if(gSensor[tempTire].status.bits.step_status&0x0e)
			{
				gSensor[tempTire].send_status.bits.bMsc_status=1;//nos;
			}
		}
		gSystem.monitor_car_node=op_data_t.arry[FLASH_OP_MAX-3];	
		gSystem.monitor_tail=op_data_t.arry[FLASH_OP_MAX-2];
		gSystem.monitor_head=op_data_t.arry[FLASH_OP_MAX-1];
		cmp_sensor_data(op_data_t.arry);	
		LOG(LEVEL_INFO,"second power on");	
	}
	else
	{
		//clear_user_data();
		memset(op_data_t.arry,0,FLASH_OP_MAX);
		u16temp=FIRST_OP_EEPROM_CONST;
		op_data_t.arry[0]=u16temp;
		op_data_t.arry[1]=u16temp>>8;
		for(tempTire=22;tempTire;)
		{
			tempTire--;
			num=tempTire*9+5+2;
			op_data_t.arry[num++]=0x03;
			op_data_t.arry[num]=0x20;				
			gSensor[tempTire].set_pressure=0x320;			
		}	
		gSystem.monitor_car_node=10;	
		gSystem.monitor_tail=22;
		gSystem.monitor_head=0;

		op_data_t.arry[FLASH_OP_MAX-3]=gSystem.monitor_car_node;	
		op_data_t.arry[FLASH_OP_MAX-2]=gSystem.monitor_tail;
		op_data_t.arry[FLASH_OP_MAX-1]=gSystem.monitor_head;	

		op_data_t.op_offset=0;
		op_data_t.op_size=FLASH_OP_MAX;
		user_data_store(&op_data_t);
		LOG(LEVEL_INFO,"first power on");	
	}
	/*connect status*/
	for(num=22;num;)
	{
		num--;
		if((num<gSystem.monitor_tail)&&(num>=gSystem.monitor_head))
		{
			gSensor[num].send_status.bits.bConnect=0;//connect;
		}
		else
		{
			gSensor[num].send_status.bits.bConnect=3;//disconnect;
		}
	}	
	gSystem.bConnect_status_back=!gSystem.bConnect_status;
	monitor_tire_status(MONITOR_CLEAN_NOS_TIME);
	monitor_tire_status(MONITOR_GET_LEVEL);	
	// Create security request timer.
	uint32_t err_code;
	err_code = app_timer_create(&m_global_timer_id,
								APP_TIMER_MODE_REPEATED,
								system_timeout_handler);
	APP_ERROR_CHECK(err_code);
}
/** reset check
 */
void system_state_init(void)
{
	system_idle_state();
	gSystem.model=M_NORMAL;
}
/** board init;
 */
void board_init(void)
{
	io_init();	
	//simple_uart_config();
	LOG(LEVEL_INFO,"uart init ok");

	timers_init();
	init_primary();

    BUZZER_ON();
	read_battery_once();
	/*keep buzzer off*/
	BUZZER_OFF();
	NRF_GPIOTE->CONFIG[0] = 0;
	nrf_gpio_cfg_output(BUZZER_PIN_NUMBER);	
	nrf_gpio_pin_clear(BUZZER_PIN_NUMBER);
}

__asm void wait()
{
    BX lr
}

void HardFault_Handler(void)
{
	//__breakpoint(0);
	wait();
	while(1);
}

