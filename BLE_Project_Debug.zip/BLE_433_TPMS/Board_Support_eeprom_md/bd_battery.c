/**
 * @file     ble51822 board.c
 * @version  SDK:6.0.0;	SoftDevice:s110_nrf51822_7.0.0
 * @Compiler Armcc.exe v5.03.076(Evaluation) 
 * @IDE			 uVisionV4.72.0.0
 * @author	 Sam
 * @date     21/09/2015(First)
 * @brief   
 *
 **/
/* Includes*/
#include "bd_battery.h"
#include <stdint.h>
#include <string.h>
#include "nordic_common.h"
#include "nrf.h"
#include "app_error.h"
#include "nrf_gpio.h"
#include "nrf51_bitfields.h"
#include "app_util.h"
#include "nrf_adc.h"
#include "nrf_delay.h"
#include "app_scheduler.h"
#include "app_util_platform.h"
#include "bd_uart_debug.h"
#include "bd_system_state_machine.h"

/** Default ADC configuration. */
#define NRF_ADC_CONFIG_BATTERY { NRF_ADC_CONFIG_RES_10BIT,               \
                                 NRF_ADC_CONFIG_SCALING_INPUT_ONE_THIRD, \
                                 NRF_ADC_CONFIG_REF_VBG }

#define ADC_TIMES_MAX (8)

#define LEVEL_LOW     462   //(3.25V)
#define LEVEL_P1      533   //(3.75V)
#define LEVEL_P2      583   //(4.10V)

#define CHANGE_VALUE 8
						
extern SYSTEM_TypeDef gSystem;			
static uint32_t m_battery_delay;
app_timer_id_t m_battery_timer_id; 

volatile  uint16_t battery_avg;																 
const uint8_t bat_level_arry[]={0,LEVEL_LOW,LEVEL_P1,LEVEL_P2};
BAT_LEVEL_STATUS smaller_level,bigger_level;
static uint8_t bigger_num,smaller_num;
static uint8_t cmp_period;
static uint8_t low_power_run_time;
volatile bool bFirst_measure;
	
BAT_LEVEL_STATUS temp_level; 

void get_battery_level(void)
{
	if(battery_avg>LEVEL_P2)
    {
        temp_level=BAT_POWER_FULL;
    }
    else if(battery_avg>LEVEL_P1)
    {
        temp_level=BAT_POWER_66;
    }
    else if(battery_avg>LEVEL_LOW)
    {
        temp_level=BAT_POWER_33;
    }
    else
    {
        temp_level=BAT_POWER_LOW;
    }
}

/* @brief battery init
  * @param  interval
  * @retval None
 */
void read_battery_once(void)
{
	nrf_adc_int_enable(ADC_INTENSET_END_Msk);
	NRF_TIMER2->TASKS_START= 1;
    bFirst_measure=false;
	while(1)
	{
		if(bFirst_measure==true)
		{
			break;
		}
	}
	get_battery_level();
	if(temp_level==BAT_POWER_LOW)
	{
		if(nrf_gpio_pin_read(BAT_DETECT_PIN_NUMBER)!=BAT_CHARGING_STATE)
   		{
   			power_system_off();
		}
	}
	gSystem.bat_level=temp_level;

	nrf_adc_int_enable(ADC_INTENSET_END_Disabled);
	NRF_TIMER2->TASKS_STOP = 1;
}
/* @brief battery init
  * @param  interval
  * @retval None
 */

void battery_timeout_handler(void* p_context)
{	
    bool bCharge_status;
	/*charge status*/
    if(nrf_gpio_pin_read(BAT_DETECT_PIN_NUMBER)==BAT_CHARGING_STATE)
    {
        bCharge_status=true;
        battery_avg=battery_avg-(BATTERY_VOLTAGE_ADJUSTMENT-gSystem.bat_level*5);
    }
    else
    {
        bCharge_status=false;
    } 
    /**/
    get_battery_level();
    /*cmp threhold*/
    if(temp_level!=gSystem.bat_level)
    {
        if(temp_level>gSystem.bat_level)
        {
            if(battery_avg>(bat_level_arry[gSystem.bat_level]+CHANGE_VALUE))
            {
                bigger_num++;
                bigger_level=temp_level;
            }
        }
        else if(temp_level<gSystem.bat_level)
        {
            if(battery_avg<(bat_level_arry[gSystem.bat_level]-CHANGE_VALUE))
            {
                smaller_num++; 
                smaller_level=temp_level;             
            }
        }
    }
    /*get level*/
    cmp_period++;
    if(cmp_period>50)
    {
        if(bigger_num>10)
        {
            gSystem.bat_level=bigger_level;
        }
        else if(smaller_num>10)
        {
            gSystem.bat_level=smaller_level;
        }
        bigger_num=0;
        smaller_num=0;
        cmp_period=0;
    }
    /*low power sleep*/
    if(gSystem.bat_level==BAT_POWER_LOW)
    {  
        if(bCharge_status==true)
        {
            low_power_run_time=0;
        }       
        else
        {
            low_power_run_time++; 
            if(low_power_run_time>=2*60)// max 255/60≈4;
            {
                low_power_run_time=0;
                wakeup_cfg(); 
            }
        }   
    }
    else
    {
      low_power_run_time=0;
    } 
}
/* @brief battery init
  * @param  interval
  * @retval None
 */
volatile static uint8_t battery_measure_timers;	
volatile static uint16_t battery_measure_arry[ADC_TIMES_MAX];	
volatile static uint16_t battery_measure_sum;

void battery_init(uint32_t ticks_per_1000ms)
{
    uint32_t err_code;
	const nrf_adc_config_t nrf_adc_config = NRF_ADC_CONFIG_BATTERY;
	nrf_gpio_cfg_input(BAT_DETECT_PIN_NUMBER,NRF_GPIO_PIN_NOPULL);
	// Initialize and configure ADC
	nrf_adc_configure( (nrf_adc_config_t *)&nrf_adc_config);
	nrf_adc_input_select(BAT_MEASURE_ANINPUT);

	NRF_LPCOMP->ENABLE=0;  
	NRF_ADC->EVENTS_END  = 0;// Stop any running conversions.	    
	NRF_ADC->TASKS_START = 0;
	NRF_ADC->TASKS_STOP  = 0;

	NRF_PPI->CH[1].EEP = (uint32_t)&NRF_TIMER2->EVENTS_COMPARE[0];
	NRF_PPI->CH[1].TEP = (uint32_t)&NRF_ADC->TASKS_START;
	NRF_PPI->CHEN |= PPI_CHEN_CH1_Enabled<<PPI_CHEN_CH1_Pos;

	NRF_TIMER2->MODE      = TIMER_MODE_MODE_Timer;
    NRF_TIMER2->BITMODE   = TIMER_BITMODE_BITMODE_16Bit<< TIMER_BITMODE_BITMODE_Pos;
    NRF_TIMER2->PRESCALER = TIMER2_PRESCALER;//16MHz->1us;	
    NRF_TIMER2->TASKS_CLEAR = 1;
    NRF_TIMER2->CC[0] = 50000;//10ms
	  /*configure the shortcut to clear and restaart on compare0*/
    NRF_TIMER2->SHORTS = (TIMER_SHORTS_COMPARE0_CLEAR_Enabled << TIMER_SHORTS_COMPARE0_CLEAR_Pos);	
   
    NVIC_SetPriority(ADC_IRQn, APP_IRQ_PRIORITY_LOW);
    NVIC_EnableIRQ(ADC_IRQn);
    // Create battery timer
	m_battery_delay=ticks_per_1000ms;
    err_code = app_timer_create(&m_battery_timer_id,
                                APP_TIMER_MODE_REPEATED,
                                battery_timeout_handler);
    APP_ERROR_CHECK(err_code);

    battery_measure_timers=0;
	battery_measure_sum=0;
	battery_avg=0;
	gSystem.bat_level=BAT_POWER_LOW;
}
/* @brief battery init
  * @param  interval
  * @retval None
 */
void battery_measure_timer_start(void)
{
	uint32_t err_code;
	// Start battery timer
	err_code = app_timer_start(m_battery_timer_id, m_battery_delay, NULL);
	APP_ERROR_CHECK(err_code);
	nrf_adc_int_enable(ADC_INTENSET_END_Msk);
	NRF_TIMER2->TASKS_START= 1;
}
/* @brief battery init
  * @param  interval
  * @retval None
 */
void battery_measure_timer_stop(void)
{
	uint32_t err_code;
	// Stop battery timer
	err_code = app_timer_stop(m_battery_timer_id);
	APP_ERROR_CHECK(err_code);
	nrf_adc_int_enable(ADC_INTENSET_END_Disabled);
	NRF_TIMER2->TASKS_STOP = 1;
}

/* @brief  ADC intterrup 
  * @param  interval
  * @retval None
 */
void ADC_IRQHandler(void)
{
	uint16_t adc_result;	
	NRF_ADC->EVENTS_END     = 0;
	adc_result              = NRF_ADC->RESULT;

	if(battery_measure_sum>battery_measure_arry[battery_measure_timers])
	{
		battery_measure_sum-=battery_measure_arry[battery_measure_timers];
	}
	battery_measure_arry[battery_measure_timers]=adc_result;
	battery_measure_sum+=adc_result;
	battery_measure_timers++;
	if(battery_measure_timers>=ADC_TIMES_MAX)
	{
		battery_measure_timers=0;
		bFirst_measure=true;
	}
	battery_avg=(battery_measure_sum>>3);	
}
