/**
 * @file     ble51822 board.c
 * @version  SDK:6.0.0;	SoftDevice:s110_nrf51822_7.0.0
 * @Compiler Armcc.exe v5.03.076(Evaluation) 
 * @IDE			 uVisionV4.72.0.0
 * @author	 Sam
 * @date     21/09/2015(First)
 * @brief   
 *
 **/
/* Includes*/
#include "bd_com_protocol.h"
#include "bd_sensor_recive.h"
#include "bd_data_manager.h"
#include "nrf_delay.h"
#include "ble_user_srv.h"
#include "app_error.h"
#include "bd_system_state_machine.h"
#include "app_scheduler.h"
#include "nrf_soc.h"

extern ble_nus_t  m_nus; 
extern SYSTEM_TypeDef gSystem;
extern SENSOR_DATA_Type gSensor[22];

/*
 *  Function: ;
 *  Parameters:
 *  Returns:NO
 *  Description:
 */  
bool update_sensor_status(uint8_t tireNum)
{
	uint8_t tireArry[8];
	uint32_t err_code;
	tireArry[0]=0x01;
	tireArry[1]=0x05;
	tireArry[2]=gSensor[tireNum].get_pressure>>8;
	tireArry[3]=gSensor[tireNum].get_pressure;
	tireArry[4]=gSensor[tireNum].temperature;
	tireArry[5]=tireNum;
	tireArry[6]=gSensor[tireNum].send_status.value;
	tireArry[7]=0x0A;	
	err_code=ble_nus_string_send(&m_nus,tireArry,8);
	
	if(err_code == BLE_ERROR_NO_TX_BUFFERS)
    {
        return false;/* ble tx buffer full*/
    }
    else if (err_code != NRF_ERROR_INVALID_STATE)
	{
		APP_ERROR_CHECK(err_code);
	}
	return true;
}
/*
 *	Function:	Send Data From Uart to BLE(after update);
 *	Parameters:
 *	Returns:NO
 *  Description:
 */	
static uint8_t first_rear_value=0;
void rec_command(uint8_t *pdata)
{
	uint8_t num;
	switch(pdata[0])
	{
		case FUNC_SYNC_CMD:
		{
			gSystem.send_cmd=CMD_SYNC;
			gSystem.bSend=1;    
		}break;
		case FUNC_LEARN_CMD:
		{		
			gSystem.send_cmd=CMD_BACK;
			gSystem.bSend=1;
			if(pdata[2]<22)
			{
				if(gSensor[pdata[2]].status.bits.bLearn_sign==false)//position no occupy;
				{
					gSystem.learnTimeOut=30;//;
					gSystem.learnNum=pdata[2]+1;					
				} 	
			}			       
		}break;
		case FUNC_CHAOSHI_CMD:
		{
			gSystem.send_cmd=CMD_BACK;
			gSystem.bSend=1;
			gSystem.learnNum=0;
		}break;
		case FUNC_DELETE_CMD:
		{
			gSystem.send_cmd=CMD_BACK;
			gSystem.bSend=1;
			if(pdata[2]<22)
			{
				remove_sensor_data(pdata[2]);
			} 
			else
			{
				monitor_tire_status(MONITOR_REMOVE_SENSOR);
			}      
		}break;
		case FUNC_SETUP_CMD:
		{
			gSystem.send_cmd=CMD_BACK;
			gSystem.bSend=1;
			//Check Receive Data;TBD;
			if(pdata[4]<22)
			{	
				uint16_t u16temp;
				u16temp=pdata[2];
				u16temp<<=8;
				u16temp|=pdata[3];
				gSensor[pdata[4]].set_pressure=u16temp;
				get_sensor_level_status(pdata[4]);
			}
			else
			{			
				uint8_t num;
				for(num=22;num;)
				{
					num--; 
					gSensor[num].set_pressure=0x320;
				}
				monitor_tire_status(MONITOR_GET_LEVEL); 
			}
		}break;
		case FUNC_CLEARN_CMD:
		{
			gSystem.send_cmd=CMD_BACK;
			gSystem.bSend=1;
			monitor_tire_status(MONITOR_CLEAN_SENSOR);
			monitor_tire_status(MONITOR_GET_LEVEL); 
		}break;
		case FUNC_CUT_REAR_CMD:
		{
			gSystem.send_cmd=CMD_BACK;
			gSystem.bSend=1;//recive two times;
			if(pdata[2])//recive second times;
			{
				gSystem.monitor_car_node=pdata[2];
				if(pdata[3]==first_rear_value)
				{
					if(first_rear_value==0x0c)
					{
						gSystem.monitor_head=0; 
						gSystem.monitor_tail=0;
					}
					else
					{
						gSystem.monitor_head=0; 
						gSystem.monitor_tail=22;
					}						
				}
				else
				{
					if(first_rear_value==0x0c)
					{
						gSystem.monitor_head=gSystem.monitor_car_node;
						gSystem.monitor_tail=22; 
					}
					else
					{
						gSystem.monitor_head=0;
						gSystem.monitor_tail=gSystem.monitor_car_node;
					}			
					
				}
				for(num=22;num;)
				{
					num--;
					if((num<gSystem.monitor_tail)&&(num>=gSystem.monitor_head))
					{
						gSensor[num].send_status.bits.bConnect=0;//connect;
					}
					else
					{
						gSensor[num].send_status.bits.bConnect=3;//disconnect;
					}
				}
				gSystem.bTire_learn=0;
			    for(num=gSystem.monitor_head;num<gSystem.monitor_tail;num++)
			    {
			        if(gSensor[num].status.bits.bLearn_sign==true)
			        {
			          gSystem.bTire_learn=1;
			          break;
			        }
			    } 	
			}
			else
			{
				first_rear_value=pdata[3];
			}	
		}break;
		default:break;
	}
}
/*
 *	Function:	Send Data From Uart to BLE(after update);
 *	Parameters:
 *	Returns:NO
 *  Description:
 */	
uint32_t u32temp;
void send_to_ble(void)
{
	uint32_t err_code;
	uint8_t cnt;
	uint8_t tireArry[8];
	switch(gSystem.send_cmd)
	{
		case CMD_SYNC:
		{
			cnt=22;
			while(cnt)
			{
				cnt--;
				if(update_sensor_status(cnt)==false)
				{
					goto tab_exception;
				}
				app_sched_execute();
				sd_app_evt_wait();
				nrf_delay_ms(20);	//packet interval 20ms send more than 20byte Data Arry;	
			}
			cnt=22;
			while(cnt)
			{
				cnt--;
				tireArry[0]=0x03;
				tireArry[1]=0x03;
				tireArry[2]=gSensor[cnt].set_pressure>>8;//HIGH BYTE FIRST;
				tireArry[3]=gSensor[cnt].set_pressure;				
				tireArry[4]=cnt;
				tireArry[5]=0;
				tireArry[6]=0;
				tireArry[7]=0x0A;	
				err_code=ble_nus_string_send(&m_nus,tireArry,8);
				if(err_code == BLE_ERROR_NO_TX_BUFFERS)
			    {
			        goto tab_exception;/* ble tx buffer full*/
			    }
			    else if (err_code != NRF_ERROR_INVALID_STATE)
				{
					//APP_ERROR_CHECK(err_code);
				}
				app_sched_execute();
				sd_app_evt_wait();
				nrf_delay_ms(20);//packet interval 20ms send more than 20byte Data Arry;		
			}				
		}break;
		case CMD_BACK:
		{
			uint8_t data_back_arry[8]={0x05,0x00,0x00,0x00,0x00,0x00,0x00,0x0a};
			err_code=ble_nus_string_send(&m_nus,data_back_arry,8);
			if(err_code == BLE_ERROR_NO_TX_BUFFERS)
		    {
		        goto tab_exception;/* ble tx buffer full*/
		    }
		    else if (err_code != NRF_ERROR_INVALID_STATE)
			{
				//APP_ERROR_CHECK(err_code);
			}
		}break;
		case CMD_UPDATE:
		{
			gSystem.bTire_learn=0;
			if((gSystem.update_tire<gSystem.monitor_tail)&&(gSystem.update_tire>=gSystem.monitor_head))
			{
				if(gSensor[gSystem.update_tire].status.bits.bLearn_sign==true)
				{
					update_sensor_status(gSystem.update_tire);
				}
			}			
		}break;
		default:break;
	}
	tab_exception:
		__nop();
}

