/**
 * @file     ble51822 board.c
 * @version  SDK:9.0.0;	SoftDevice:s110_nrf51822_8.0.0
 * @Compiler Armcc.exe v5.03.076(Evaluation) 
 * @IDE			 uVisionV4.72.0.0
 * @author	 Sam
 * @date     21/09/2015(First)
 * @brief   
 *
 **/
/* Includes*/
#include "bd_buffer.h"

#define IS_BUFFER_EMPTY(Read, Write)              (Write == Read)
#define IS_BUFFER_FULL(Read, Write, Size)         (((Write + 1) % Size) == Read)


/* @brief  Buffer initialization.
  * @param  pBuffer: Pointer of Buffer_TypeDef
  * @param  puMemory: Memory allocate by application
  * @param  uSize: Memory Size
  * @retval None
 */
 void buffer_init(Buffer_TypeDef *pbuffer, uint8_t *memory, uint8_t size)
{
  pbuffer->uRead = 0;
  pbuffer->uWrite = 0;
  pbuffer->puMemory = memory;
  pbuffer->uSize = size;
}
/* @brief  Read buffer.
  * @param  pBuffer: Pointer of Buffer_TypeDef
  * @param  puData: Pointer of dada buffer for read
  * @param  uLength: Read length
  * @retval uCount: Data length of read operation
  */
bool buffer_read(Buffer_TypeDef *pBuffer, uint8_t *puData, uint8_t uLength)
{
  uint8_t uCount;
  bool uResult=false;
  if(!IS_BUFFER_EMPTY(pBuffer->uRead, pBuffer->uWrite))
  {
    for (uCount = 0; uCount < uLength; uCount++)
    {
        *puData = pBuffer->puMemory[pBuffer->uRead];
        puData++;
        pBuffer->uRead = (pBuffer->uRead + 1) % pBuffer->uSize;
    } 
    uResult=true;
  }
  return uResult;
}

/* @brief  Write Buffer.
  * @param  pBuffer: Pointer of Buffer_TypeDef
  * @param  puData: Pointer of dada buffer for write
  * @param  uLength: Write length
  * @retval uCount: Data length of write operation
  */
bool buffer_write(Buffer_TypeDef *pBuffer, uint8_t *puData, uint8_t uLength)
{
  uint8_t uCount = 0;
  bool uResult=false;
  if (!IS_BUFFER_FULL(pBuffer->uRead, pBuffer->uWrite, pBuffer->uSize))
  {
    for (uCount = 0; uCount < uLength; uCount++)
    {
      pBuffer->puMemory[pBuffer->uWrite] = *puData;
      puData++;
      pBuffer->uWrite = (pBuffer->uWrite + 1) % pBuffer->uSize;
    }
    uResult=true;
  }	
  return uResult;
}
/* Private functions */
