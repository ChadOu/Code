/**
 * @file     RF_Test board.c
 * @version  SDK:9.0.0;	SoftDevice:s110_nrf51822_8.0.0
 * @Compiler Armcc.exe v5.03.076(Evaluation) 
 * @IDE			 uVisionV4.72.0.0
 * @author	 sam
 * @date     21/09/2015(First)
 * @brief   
 *
 **/

#ifndef __BD_BATTERY_H__
#define __BD_BATTERY_H__
//#include "app_scheduler.h"
#include "app_timer.h"

#define ADC_INPUT_CHANNEL  ADC_CONFIG_PSEL_AnalogInput3
#define ADC_REF_VOLTAGE_IN_MILLIVOLTS        1200                                     /**< Reference voltage (in  milli volts) used by ADC while doing conversion. */
#define ADC_PRE_SCALING_COMPENSATION         3                                         /**< The ADC is configured to use VDD with no prescaling as input. And hence the result of conversion is to be multiplied by 3 to get the actual value of the battery voltage.*/
#define ADC_HW_PRE_SCALING_COMPENSATION      2

#define BATTERY_ADC_RESOLUTION  (ADC_CONFIG_RES_10bit)
#define BATTERY_ADC_DIV         (1024)

#define BAT_DETECT_PIN_NUMBER 	2 //CHARGE_ST:new:2,old:7
#define BAT_CHARGING_STATE			0
#define BAT_MEASURE_ANINPUT		NRF_ADC_CONFIG_INPUT_4 
#define BAT_MEASURE_PIN_NUMBER 	3 //P0_03->AN4;no change;

#define BATTERY_VOLTAGE_ADJUSTMENT           60     /**< Adjustment for charging */

#define TIMER2_PRESCALER 4

typedef enum
{
  BAT_POWER_LOW=0,
  BAT_POWER_33,
  BAT_POWER_66,
  BAT_POWER_FULL,
}BAT_LEVEL_STATUS;

/**@brief Macro to convert the result of ADC conversion in millivolts.
 *
 * @param[in]  ADC_VALUE   ADC result.
 * @retval     Result converted to 0.1 millivolts.
 */
#define ADC_RESULT_IN_MILLI_VOLTS(ADC_VALUE)\
			(((ADC_VALUE) * ADC_REF_VOLTAGE_IN_MILLIVOLTS*ADC_PRE_SCALING_COMPENSATION*ADC_HW_PRE_SCALING_COMPENSATION)/(BATTERY_ADC_DIV))
				
/**@brief Function to make the ADC start a battery level conversion
 */
void battery_measure_timer_start(void);
void battery_measure_timer_stop(void);
void read_battery_once(void);
void battery_init(uint32_t ticks_per_1000ms);

#endif
/** @} */
/** @endcond */
