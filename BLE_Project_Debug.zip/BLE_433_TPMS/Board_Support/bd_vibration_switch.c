/**
 * @file     ble51822 board.c
 * @version  SDK:9.0.0;	SoftDevice:s110_nrf51822_8.0.0
 * @Compiler Armcc.exe v5.03.076(Evaluation) 
 * @IDE			 uVisionV5.15.0.0
 * @author	 Sam
 * @date     21/09/2015(First)
 * @brief   
 *
 **/
/* Includes*/
#include "bd_system_state_machine.h"
#include "bd_vibration_switch.h"
#include "nrf_gpio.h"
#include "app_timer.h"
#include "ble_user_srv.h"
#include "app_util_platform.h"
#include "bd_uart_debug.h"
#include "bd_buzzer.h"

extern SYSTEM_TypeDef gSystem;
extern buzzer_status_t buzzer_state;
 
static app_timer_id_t m_vibration_check_timer_id;

static uint32_t m_vibration_scan_delay;
#define ARRY_SIZE 50
#define VIBRATION_SW_STABLE	0
static uint8_t vibration_sw_arry[ARRY_SIZE];
static uint8_t arry_cnt;
static uint8_t vibration_sw_time;
static uint16_t vibration_sw_stable_time;

static void vibration_scan_timeout_handler(void* p_context)
{
	if(vibration_sw_arry[arry_cnt%ARRY_SIZE]==1)
	{
		if(vibration_sw_time)
		{
			vibration_sw_time--;		
		}
	}	
	if(nrf_gpio_pin_read(VIBRATION_SWITCH_NUMBER)==VIBRATION_SW_STABLE)
	{
		vibration_sw_arry[arry_cnt%ARRY_SIZE]=0;		
	}
	else
	{
		vibration_sw_arry[arry_cnt%ARRY_SIZE]=1;
		vibration_sw_time++;	
	}
	arry_cnt++;
	//LOG(LEVEL_INFO,"vibration_sw_time:%d",vibration_sw_time);
	if(buzzer_state==BUZZER_STATE_ON)
	{
		vibration_sw_time=0;
	}
	if(vibration_sw_time>10)
	{
		LOG(LEVEL_INFO,"zheng dong!");
		vibration_sw_time=0;
		vibration_sw_stable_time=0;
	}
}

void vibration_detect_handler(void)
{
	vibration_sw_stable_time++;//1s;
	if(vibration_sw_stable_time>=1800)//30*60
	{
		vibration_sw_stable_time=0;
		nrf_gpio_cfg_sense_set(VIBRATION_SWITCH_NUMBER,NRF_GPIO_PIN_SENSE_HIGH);
		gSystem.sleep_value=SLEEP_MODEL_VIBRATION;
		wakeup_cfg();
	}
}
	
void vibration_switch_timer_start(void)
{
	vibration_sw_time=0;
	arry_cnt=0;
	vibration_sw_stable_time=0;
	app_timer_start(m_vibration_check_timer_id, m_vibration_scan_delay, NULL);
}

void vibration_switch_timer_stop(void)
{
	app_timer_stop(m_vibration_check_timer_id);
}

/**
  * @brief 
  * @param 
  * @retval
  */
void vibration_switch_init(uint32_t ticks_per_10ms)
{
	uint32_t err_code;
	m_vibration_scan_delay=ticks_per_10ms;
	nrf_gpio_cfg_input(VIBRATION_SWITCH_NUMBER,NRF_GPIO_PIN_NOPULL);//scan mode
    //Create battery timer
	err_code = app_timer_create(&m_vibration_check_timer_id,
															APP_TIMER_MODE_REPEATED,
															vibration_scan_timeout_handler);
	APP_ERROR_CHECK(err_code);
}
	
/* Private functions */
