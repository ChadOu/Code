
#ifndef __BD_LED_FLASH_H__
#define __BD_LED_FLASH_H__

#include <stdint.h>
#include "nrf_gpio.h"
#include "nrf.h"
#include "app_timer.h"

#define LED_OFFSET 4

#define LED_YELLOW_PIN_NUMBER   (LED_OFFSET+0) //new:4  old:1
#define LED_RED_PIN_NUMBER 		(LED_OFFSET+1) //new:5  old:0
#define LED_BLUE_PIN_NUMBER		(LED_OFFSET+2) //new:6  old:2

#define LED_FAST_BLINK_ON	2
#define LED_FAST_BLINK_OFF	LED_FAST_BLINK_ON+2
#define LED_SLOW_BLINK_ON	4
#define LED_SLOW_BLINK_OFF	LED_FAST_BLINK_ON+4

typedef enum
{
	T_YELLOW_LED=0,
	T_RED_LED=1,
	T_BLUE_LED=2,
}leds_type;

typedef enum
{
	LED_OFF=0,
	LED_ON=1,
	LED_BLINK_FAST=2,
    LED_BLINK_SLOW=4,
}leds_status;

void leds_init(uint32_t ticks_per_100ms);

void leds_control(leds_type les_t,leds_status status);

#endif // buzzer_H__

/** @} */
/** @endcond */
