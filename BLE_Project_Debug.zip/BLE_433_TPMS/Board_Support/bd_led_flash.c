/**
 * @file     ble51822 board.c
 * @version  SDK:6.0.0;	SoftDevice:s110_nrf51822_7.0.0
 * @Compiler Armcc.exe v5.03.076(Evaluation) 
 * @IDE			 uVisionV4.72.0.0
 * @author	 sam
 * @date     21/09/2015(First)
 * @brief   
 *
 **/ 
/* Includes*/
#include "bd_led_flash.h"
#include <string.h>
#include "nordic_common.h"
#include "app_error.h"
#include "app_util.h"
#include "nrf_soc.h"



static app_timer_id_t m_leds_timer_id;
static uint32_t m_led_delay;
static uint8_t leds_arry[4];
static uint16_t leds_period[4];
/**
  * @brief 
  * @param 
  * @retval
  */
static void leds_timeout_handler(void* p_context)
{
	uint8_t i;
	for(i=4;i;)
	{
		i--;
		if(leds_arry[i]==LED_BLINK_FAST)
		{
			leds_period[i]++;
			if(leds_period[i]<LED_FAST_BLINK_ON)
			{
				nrf_gpio_pin_set(i+LED_OFFSET);
			}
			else if(leds_period[i]<LED_FAST_BLINK_OFF)
			{
				nrf_gpio_pin_clear(i+LED_OFFSET);
			}
			else
			{
				leds_period[i]=0;
			}
		}
		else if(leds_arry[i]==LED_BLINK_SLOW)
		{
			leds_period[i]++;
			if(leds_period[i]<LED_SLOW_BLINK_ON)
			{
				nrf_gpio_pin_set(i+LED_OFFSET);
			}
			else if(leds_period[i]<LED_SLOW_BLINK_OFF)
			{
				nrf_gpio_pin_clear(i+LED_OFFSET);
			}
			else
			{
				leds_period[i]=0;
			}
		}
	}
}
/**
  * @brief 
  * @param 
	* @retval EXAMPLE:	leds_control(T_YELLOW_LED,LED_ON);
	*								    leds_control(T_BLUE_LED,LED_BLINK_FAST);
	*									  leds_control(T_RED_LED,LED_BLINK_SLOW);
  */
static uint8_t delay_status=0;
static uint8_t delay_status_back=0;
void leds_control(leds_type les_t,leds_status status)
{
	uint8_t i;
	leds_arry[les_t]=status;
	//app_timer_stop(m_leds_timer_id);//sync+ddd
	for(i=4;i;)
	{
		i--;
		if(leds_arry[i]&0x06)
		{
			if(delay_status==0)
			{
				delay_status=1;
				app_timer_start(m_leds_timer_id, m_led_delay, NULL);
			}			
			break;
		}
		if(i==0)
		{
			delay_status=0;
		}
	}	

	if(delay_status==0)
	{
		if(delay_status_back==1)
		{
			app_timer_stop(m_leds_timer_id);
		}		
	}
	delay_status_back=delay_status;
	/*normal on or off*/
	if(leds_arry[les_t]==LED_ON)
	{
		leds_period[les_t]=0;
		nrf_gpio_pin_set(les_t+LED_OFFSET);
	}
	else if(leds_arry[les_t]==LED_OFF)
	{
		leds_period[les_t]=0;
		nrf_gpio_pin_clear(les_t+LED_OFFSET);
	}
}

/**
  * @brief 
  * @param 
  * @retval
  */
void leds_init(uint32_t ticks_per_100ms)
{
	/*CONFIG LED IO*/
	nrf_gpio_cfg_output(LED_BLUE_PIN_NUMBER);
	nrf_gpio_cfg_output(LED_RED_PIN_NUMBER);  
	nrf_gpio_cfg_output(LED_YELLOW_PIN_NUMBER);
	/*INIT LED*/
	nrf_gpio_pin_clear(LED_BLUE_PIN_NUMBER);
	nrf_gpio_pin_clear(LED_RED_PIN_NUMBER);
	nrf_gpio_pin_clear(LED_YELLOW_PIN_NUMBER);
	// Create battery timer
	m_led_delay=ticks_per_100ms;
	uint32_t err_code = app_timer_create(&m_leds_timer_id,
											APP_TIMER_MODE_REPEATED,
											leds_timeout_handler);
	APP_ERROR_CHECK(err_code);
}

