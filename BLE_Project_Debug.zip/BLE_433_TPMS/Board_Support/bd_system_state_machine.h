
#ifndef __BD_SYSTEM_STATE_MACHINE_H__
#define __BD_SYSTEM_STATE_MACHINE_H__

#include "stdint.h"
#include <stdbool.h>

#define APP_TIMER_PRESCALER              0                                          /**< Value of the RTC1 PRESCALER register. */

#define SLEEP_MODEL_VIBRATION		(0x3535)
	typedef enum 
	{
		CMD_SYNC=0,
		CMD_BACK,
		CMD_UPDATE, //contain exception
	}SEND_TypeDef;

	typedef enum
	{
		M_STARTUP=0,
		M_GOTO_SLEEP,
		M_SLEEP,
		M_GOTO_NORMAL,
		M_NORMAL,
	}SYSTEM_STATE_TypeDef;

	typedef enum
	{
		FIX_NORMAL=0,
		FIX_UNDER_50KPA,
		FIX_REGULAR_EXCEPTION,
		FIX_NOS,
		FIX_REMOVE,
	}SENSRO_STATE;

	typedef enum
	{
	  MONITOR_COMPARE=0,
	  MONITOR_NOS,  
	  MONITOR_ALARM,
	  MONITOR_PW_ON,
	  MONITOR_CLEAN_NOS_TIME,
	  MONITOR_GET_LEVEL,
	  MONITOR_REMOVE_SENSOR,
	  MONITOR_CLEAN_SENSOR,
	  MONITOR_SAVE_SENSOR,
	  MONITOR_NOS_SEND,
	}MONITOR_TIRE_ENUM;

	typedef struct
	{
		SENSRO_STATE state;
		uint8_t times;
		uint8_t time_space;
		uint8_t bAlarm_on:1;		
		uint8_t bBuzzer_done:1;
		uint8_t bAlarm_doing:1;
	}SENSOR_STATE_TypeDef;

	typedef struct 
	{
		uint32_t monitor_car_node;
		uint8_t monitor_head;
		uint8_t monitor_tail;
		uint32_t update_tire;
		uint8_t learnNum;
		uint32_t learnTimeOut;
		uint8_t bSave;
		uint8_t bSave_done;
		SEND_TypeDef send_cmd;
		SYSTEM_STATE_TypeDef model;
		SENSOR_STATE_TypeDef sensor;
		uint8_t bSend:1;
		uint8_t bConnect_status :1;
		uint8_t bConnect_status_back :1;
		uint8_t bException:1;
		uint8_t bException_action:1;
		uint8_t bException_action_back:1;
		uint8_t bException_back:1;
		uint8_t bLow_power:1;
		uint8_t bTire_learn:1;
		uint8_t bLow_power_back:1;
		uint8_t bDebug_rx_twi:1;
		uint8_t bDebug_rx_twi_back:1;
		uint8_t bSync_space_ok:1;
		uint8_t bSync_send_done:1;
		uint8_t low_power_times;
		uint8_t bat_level;
		uint16_t sleep_value;
	}SYSTEM_TypeDef;

void timers_init(void);
void application_timers_start(void);
void application_timers_stop(void);
void application_timers_start(void);
void sleep_mode_enter(void);
void board_init(void);
void system_state_init(void);
void wakeup_cfg(void);
void remove_sensor_data(uint8_t num);
void monitor_tire_status(MONITOR_TIRE_ENUM m_status);

#endif
		