
#ifndef __BD_BUZZER_H__
#define __BD_BUZZER_H__

#include <stdint.h>
#include "nrf_gpio.h"
#include "nrf.h"
#include "app_timer.h"

#define PPI_CHAN0_TO_TOGGLE_BUZZER           0                                         /*!< The PPI Channel that connects CC0 compare event to the GPIOTE Task that toggles the Advertising LED. */
#define GPIOTE_CHAN_FOR_BUZZER_TASK          0                                         /*!< The GPIOTE Channel used to perform write operation on the Advertising LED pin. */
#define TIMER1_PRESCALER                      4                                         /*!< Prescaler setting for timer. */
#define CAPTURE_COMPARE_0_VALUE              1666 	//0x1E84                                    /*!< Capture compare value that corresponds to 250 ms. */

#define BUZZER_PIN_NUMBER      10 //new:10;old:4	  /**< Pin that can be used by applications to indicate advertising state.*/			
				

typedef enum
{
  BUZZER_INIT=0,
  BUZZER_BI_ONCE, //1.
  BUZZER_BI_TWICE,  //2.
	BUZZER_BI_ALARM,  //8.
} buzzer_model_t;

typedef enum
{
  BUZZER_STATE_OFF=0, //
  BUZZER_STATE_ON,  //
} buzzer_status_t;
				
void buzzer_init(uint32_t ticks_per_100ms);
void buzzer_control(buzzer_model_t modle);
void BUZZER_ON(void);
void BUZZER_OFF(void);
#endif // buzzer_H__

/** @} */
/** @endcond */
