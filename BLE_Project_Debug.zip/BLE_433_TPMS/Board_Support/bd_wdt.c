/**
 * @file     ble51822 board.c
 * @version  SDK:6.0.0;	SoftDevice:s110_nrf51822_7.0.0
 * @Compiler Armcc.exe v5.03.076(Evaluation) 
 * @IDE			 uVisionV4.72.0.0
 * @author	 Sam
 * @date     21/09/2015(First)
 * @brief   
 *
 **/
/* Includes*/
#include "nrf51.h"
#include "nrf51_bitfields.h"

#define RELOAD_COUNT (32768*60*3-1)    //3 minutes
/**
  * @brief 
  * @param 
  * @retval
  */
void wdt_init(void)
{
    NRF_WDT->TASKS_START = 0;
    NRF_WDT->CRV = RELOAD_COUNT;
    NRF_WDT->CONFIG =
        WDT_CONFIG_HALT_Pause << WDT_CONFIG_HALT_Pos |
        WDT_CONFIG_SLEEP_Pause << WDT_CONFIG_SLEEP_Pos;
    NRF_WDT->RREN = WDT_RREN_RR0_Enabled << WDT_RREN_RR0_Pos;
}
/**
  * @brief 
  * @param 
  * @retval
  */
void wdt_start(void)
{
    NRF_WDT->TASKS_START = 1;
}
/**
  * @brief 
  * @param 
  * @retval
  */
void wdt_feed(void)
{
    if(NRF_WDT->RUNSTATUS & WDT_RUNSTATUS_RUNSTATUS_Msk)
        NRF_WDT->RR[0] = WDT_RR_RR_Reload;
}
/**
  * @brief 
  * @param 
  * @retval
  */
void wdt_stop(void)
{
    NRF_WDT->TASKS_START = 0;
}
