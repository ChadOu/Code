
#ifndef __BD_BUTTON_H
#define __BD_BUTTON_H

#include "nrf.h"
#include "stdint.h"
#include <stdbool.h>

#define BUTTON_POWER_PIN_NUMBER 	9 //new:9;old:5

#define BUTTON_PRESS	0

#define EXT_INPUT_INTERVAL_MS (APP_TIMER_TICKS(50, 0))

  typedef struct 
  {   
    uint8_t pressHoldTime; // 
    uint8_t bPressLong	:1;
		uint8_t releaseHoldTime;
		uint8_t bRelease	:1;
  }EXT_TypeDef;

	/**@brief BSP events.
 *
 * @note Events from BSP_EVENT_KEY_0 to BSP_EVENT_KEY_LAST are by default assigned to buttons.
 */
typedef enum
{
    BUTTON_EVENT_NOTHING = 0,                  /**< Assign this event to an action to prevent the action from generating an event (disable the action). */
    BUTTON_EVENT_WAKEUP,                      /**< Assign this event to an action to assign the default event to the action. */
    BUTTON_EVENT_SLEEP,                        /**< The device should enter sleep mode. */
		BUTTON_EVENT_RELEASE,
	  BUTTON_EVENT_PRESS,
} button_event_t;
	
/**@brief BSP module event callback function type.
 *
 * @details     Upon an event in the BSP module, this callback function will be called to notify
 *              the application about the event.
 *
 * @param[in]   bsp_event_t BSP event type.
 */
typedef void (* button_event_callback_t)(button_event_t);

void button_init(uint32_t ticks_per_10ms, button_event_callback_t callback);

void button_detect_timer_start(void);
void button_detect_timer_stop(void);

#endif
