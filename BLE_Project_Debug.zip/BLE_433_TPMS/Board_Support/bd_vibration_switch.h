
#ifndef __BD_VIBRATION_SWITCH_H
#define __BD_VIBRATION_SWITCH_H

#include "stdint.h"
#include <stdbool.h>
#include "app_timer.h"

#define VIBRATION_SWITCH_NUMBER	 1 //new:1 old:12;

void vibration_switch_timer_start(void);
void vibration_switch_timer_stop(void);
	
void vibration_detect_handler(void);
void vibration_switch_init(uint32_t ticks_per_10ms);

#endif
