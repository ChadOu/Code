
#include <stdint.h>
#include <string.h>
#include "bd_data_manager.h"
#include "bd_uart_debug.h"
#include "bd_sensor_recive.h"
#include "bd_system_state_machine.h"
#include "nrf_soc.h"
#include "pstorage.h"
#include "app_scheduler.h"
#include "bd_twi_master.h"
#include "nrf_delay.h"

extern uint8_t word_addr;
extern bool bEeprom_page_addr_change;

void read_flash_data_out(DATA_SAVE_TYPE *op_data)
{
	if(twi_master_transfer(I2C_SLAVE_EEPROM_ADDR,&(op_data->op_offset),1,TWI_DONT_ISSUE_STOP))
	{
		 if(twi_master_transfer(I2C_SLAVE_EEPROM_ADDR|TWI_READ_BIT,op_data->arry,op_data->op_size,TWI_ISSUE_STOP))
		 {
			 __nop();
		 }
	}  
}

void user_data_store(DATA_SAVE_TYPE *op_data)
{
	uint8_t cnt,i;
	word_addr=0;
	bEeprom_page_addr_change=1;
	cnt=FLASH_OP_MAX/EEPROM_PAGE_SIZE;
	for(i=0;i<cnt;i++)
	{
		twi_master_transfer(I2C_SLAVE_EEPROM_ADDR,op_data->arry+i*EEPROM_PAGE_SIZE,EEPROM_PAGE_SIZE,TWI_ISSUE_STOP);
		sd_app_evt_wait();
			app_sched_execute();
			nrf_delay_ms(6);//page cycle time space time;
/*		app_sched_execute();
		nrf_delay_ms(6);//page cycle time space time;
		sd_app_evt_wait();*/
	}
	twi_master_transfer(I2C_SLAVE_EEPROM_ADDR,(op_data->arry+cnt*EEPROM_PAGE_SIZE),(FLASH_OP_MAX-cnt*EEPROM_PAGE_SIZE),TWI_ISSUE_STOP);	
	bEeprom_page_addr_change=0;	
}



