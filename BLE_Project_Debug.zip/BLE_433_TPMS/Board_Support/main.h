
#ifndef __MAIN_H
#define __MAIN_H


//DEBUG_LOG  define;
/*include*/
#include <stdint.h>
#include <string.h>
#include "nordic_common.h"
#include "nrf.h"
#include "app_error.h"
#include "nrf51_bitfields.h"
#include "ble.h"
#include "ble_hci.h"
#include "ble_srv_common.h"
#include "ble_advdata.h"
#include "ble_advertising.h"
#include "ble_conn_params.h"
#include "softdevice_handler.h"
#include "app_timer.h"
#include "device_manager.h"
#include "pstorage.h"
#include "app_trace.h"
	#ifdef BLE_DFU_APP_SUPPORT
#include "ble_dfu.h"
#include "dfu_app_handler.h"
	#endif
#include "nrf_delay.h"

#define IS_SRVC_CHANGED_CHARACT_PRESENT  1                                          /**< Include or not the service_changed characteristic. if not enabled, the server's database cannot be changed for the lifetime of the device*/

#define DEVICE_NAME                      "TM-Blue22" //TM-Blue22  JET_TPMS                             /**< Name of device. Will be included in the advertising data. */
#define MANUFACTURER_NAME                "JETSON"                      /**< Manufacturer. Will be passed to Device Information Service. */

#define TX_POWER_LEVEL                    (4) //4,0,-4,-8  

#define APP_ADV_FAST_INTERVAL           1216 //760ms                                          /**< The advertising interval (in units of 0.625 ms). The default value corresponds to 25 ms. */
#define APP_ADV_FAST_TIMEOUT            0                                         /**< The advertising time-out in units of seconds. */

#define APP_TIMER_MAX_TIMERS             10 //(6+BSP_APP_TIMERS_NUMBER)                  /**< Maximum number of simultaneously created timers. */
#define APP_TIMER_OP_QUEUE_SIZE          10                                         /**< Size of timer operation queues. */

#define MIN_CONN_INTERVAL                MSEC_TO_UNITS(20, UNIT_1_25_MS)           /**20  Minimum acceptable connection interval (0.1 seconds). 30*/
#define MAX_CONN_INTERVAL                MSEC_TO_UNITS(400, UNIT_1_25_MS)           /**500  < Maximum acceptable connection interval (0.2 second). 150*/
#define SLAVE_LATENCY                    2                                          /**2 0< Slave latency. */
#define CONN_SUP_TIMEOUT                 MSEC_TO_UNITS(6000, UNIT_10_MS)            /**6000  < Connection supervisory timeout (4 seconds). */

#define FIRST_CONN_PARAMS_UPDATE_DELAY   APP_TIMER_TICKS(5*1000, APP_TIMER_PRESCALER) /**5  < Time from initiating event (connect or start of notification) to first time sd_ble_gap_conn_param_update is called (5 seconds). */
#define NEXT_CONN_PARAMS_UPDATE_DELAY    APP_TIMER_TICKS(30*1000, APP_TIMER_PRESCALER)/**30   < Time between each call to sd_ble_gap_conn_param_update after the first call (30 seconds). */
#define MAX_CONN_PARAMS_UPDATE_COUNT     3                                          /**< Number of attempts before giving up the connection parameter negotiation. */

#define SEC_PARAM_TIMEOUT               30                                          /**< Timeout for Pairing Request or Security Request (in seconds). */
#define SEC_PARAM_BOND                   1                                          /**< Perform bonding. */
#define SEC_PARAM_MITM                   0                                          /**< Man In The Middle protection not required.ÖÐ¼äÈËÇÔÌý±£»¤ÇëÇó ÅäºÏOOBÖÃÎ»*/
#define SEC_PARAM_IO_CAPABILITIES        BLE_GAP_IO_CAPS_NONE //BLE_GAP_IO_CAPS_NONE   BLE_GAP_IO_CAPS_DISPLAY_YESNO  BLE_GAP_IO_CAPS_DISPLAY_ONLY                    /**< No I/O capabilities. */
#define SEC_PARAM_OOB                    0                                          /**< Out Of Band data not available. */
#define SEC_PARAM_MIN_KEY_SIZE           7                                          /**< Minimum encryption key size. */
#define SEC_PARAM_MAX_KEY_SIZE           16                                         /**< Maximum encryption key size. */

#define DEAD_BEEF                        0xDEADBEEF                                 /**< Value used as error code on stack dump, can be used to identify stack location on stack unwind. */

#define MODEL_NUM                       "JT_BLE_TPMS_01"                           				/**< Model number. Will be passed to Device Information Service. */
#define MANUFACTURER_ID                 0x1122334455                               /**< Manufacturer ID, part of System ID. Will be passed to Device Information Service. */
#define ORG_UNIQUE_ID                   0x667788   

#define SCHED_MAX_EVENT_DATA_SIZE sizeof(app_timer_event_t)            /**< Maximum size of scheduler events. Note that scheduler BLE stack events do not contain any data, as the events are being pulled from the stack in the event handler. */
#define SCHED_QUEUE_SIZE          10                                   /**< Maximum number of events in the scheduler queue. */

#define STATIC_PASSKEY			"333111" 									/**< Static pin. ref:BLE_GAP_PASSKEY_LEN=6bit */
	
#define SECURITY_REQUEST_DELAY          APP_TIMER_TICKS(5000, APP_TIMER_PRESCALER)  /**< Delay after connection until security request is sent, if necessary (ticks). */                                        /**< Size of timer operation queues. */

#ifdef BLE_DFU_APP_SUPPORT
#define DFU_REV_MAJOR                    0x00                                       /** DFU Major revision number to be exposed. */
#define DFU_REV_MINOR                    0x01                                       /** DFU Minor revision number to be exposed. */
#define DFU_REVISION                     ((DFU_REV_MAJOR << 8) | DFU_REV_MINOR)     /** DFU Revision number to be exposed. Combined of major and minor versions. */
#define APP_SERVICE_HANDLE_START         0x000C                                     /**< Handle of first application specific service when when service changed characteristic is present. */
#define BLE_HANDLE_MAX                   0xFFFF                                     /**< Max handle value in BLE. */

STATIC_ASSERT(IS_SRVC_CHANGED_CHARACT_PRESENT);                                     /** When having DFU Service support in application the Service Changed Characteristic should always be present. */
#endif // BLE_DFU_APP_SUPPORT

#define LFCLK_FREQUENCY           (32768UL)                 /*!< LFCLK frequency in Hertz, constant */
#define RTC_FREQUENCY             (1UL)                     /*!< required RTC working clock RTC_FREQUENCY Hertz. Changable 1Hz*/
#define COMPARE_COUNTERTIME       (1UL)                     /*!< Get Compare event COMPARE_TIME seconds after the counter starts from 0 */
#define COUNTER_PRESCALER         ((LFCLK_FREQUENCY/RTC_FREQUENCY) - 1)  /* f = LFCLK/(prescaler + 1) */

#endif 
