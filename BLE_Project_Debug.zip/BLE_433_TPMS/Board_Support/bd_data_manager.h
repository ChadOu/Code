
#ifndef __BD_DATA_MANAGER_H__
#define __BD_DATA_MANAGER_H__

#include <stdint.h>

#define FLASH_OP_FLAG_OFFSET (0)
#define FLASH_OP_FLAG_SIZE (4)

#define FLASH_OP_SENSOR_OFFSET (FLASH_OP_FLAG_SIZE)
#define SAVE_DATA_GROUP_SIZE	(10)
#define FLASH_OP_SENSOR_SIZE (22*SAVE_DATA_GROUP_SIZE) //220

#define FLASH_OP_MAX (FLASH_OP_SENSOR_SIZE+FLASH_OP_SENSOR_OFFSET+3) //220+4+4=228

#define FIRST_OP_EEPROM_CONST (0Xa5a5)

typedef struct
{
	uint8_t arry[FLASH_OP_MAX];
	uint8_t op_size;
	uint8_t op_offset;	
}DATA_SAVE_TYPE;


//void reset_check(void);
//void pstorage_user_data_init(void);
void read_flash_data_out(DATA_SAVE_TYPE *op_data);
//void clear_user_data(void);
void user_data_store(DATA_SAVE_TYPE *op_data);
void user_data_update(DATA_SAVE_TYPE *op_data);

#endif //__BD_DATA_MANAGER_H__
