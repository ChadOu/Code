/* Copyright (c) 2009 Nordic Semiconductor. All Rights Reserved.
 *
 * The information contained herein is property of Nordic Semiconductor ASA.
 * Terms and conditions of usage are described in detail in NORDIC
 * SEMICONDUCTOR STANDARD SOFTWARE LICENSE AGREEMENT.
 *
 * Licensees are granted free, non-transferable use of the information. NO
 * WARRANTY of ANY KIND is provided. This heading must NOT be removed from
 * the file.
 *
 */

#include <stdio.h>
#include <stdarg.h>
#include <stdint.h>

#include "nrf.h"
#include "bd_uart_debug.h"
#include "nrf_delay.h"
#include "nrf_gpio.h"

//uint8_t simple_uart_get(void)
//{
//    while (NRF_UART0->EVENTS_RXDRDY != 1)
//    {
//        // Wait for RXD data to be received
//    }

//    NRF_UART0->EVENTS_RXDRDY = 0;
//    return (uint8_t)NRF_UART0->RXD;
//}


//bool simple_uart_get_with_timeout(int32_t timeout_ms, uint8_t * rx_data)
//{
//    bool ret = true;

//    while (NRF_UART0->EVENTS_RXDRDY != 1)
//    {
//        if (timeout_ms-- >= 0)
//        {
//            // wait in 1ms chunk before checking for status.
//            nrf_delay_us(1000);
//        }
//        else
//        {
//            ret = false;
//            break;
//        }
//    } // Wait for RXD data to be received.

//    if (timeout_ms >= 0)
//    {
//        // clear the event and set rx_data with received byte.
//        NRF_UART0->EVENTS_RXDRDY = 0;
//        *rx_data                 = (uint8_t)NRF_UART0->RXD;
//    }

//    return ret;
//}

void simple_uart_put(uint8_t cr)
{
    NRF_UART0->TXD = (uint8_t)cr;

    while (NRF_UART0->EVENTS_TXDRDY != 1)
    {
        // Wait for TXD data to be sent.
    }

    NRF_UART0->EVENTS_TXDRDY = 0;
}


void simple_uart_putstring(const uint8_t * str)
{
    uint_fast8_t i  = 0;
    uint8_t      ch = str[i++];

    while (ch != '\0')
    {
        simple_uart_put(ch);
        ch = str[i++];
    }
}

void simple_uart_config()
{
/** @snippet [Configure UART RX and TX pin] */
    nrf_gpio_cfg_output(TXD_PIN_NUMBER);
    nrf_gpio_cfg_input(RXD_PIN_NUMBER, NRF_GPIO_PIN_NOPULL);

    NRF_UART0->PSELTXD = TXD_PIN_NUMBER;
    NRF_UART0->PSELRXD = RXD_PIN_NUMBER;
/** @snippet [Configure UART RX and TX pin] */
    NRF_UART0->BAUDRATE      = (UART_BAUDRATE_BAUDRATE_Baud115200 << UART_BAUDRATE_BAUDRATE_Pos);
	  NRF_UART0->CONFIG 			 = (UART_CONFIG_PARITY_Excluded << UART_CONFIG_PARITY_Pos);	
	  NRF_UART0->ENABLE        = (UART_ENABLE_ENABLE_Enabled << UART_ENABLE_ENABLE_Pos);
    NRF_UART0->TASKS_STARTTX = 1;
    NRF_UART0->TASKS_STARTRX = 1;
    NRF_UART0->EVENTS_RXDRDY = 0;
    NRF_UART0->EVENTS_TXDRDY = 0;
}
/*example:LOG(LEVEL_INFO,"Global_Time:%d-%d-%d\n",tm->year,tm->month,tm->day);*/
/* LOG(LEVEL_WARNING,"Must Erase All User Data!!!!");LOG(LEVEL_WARNING,"check write 0 success \r\n");*/
 void __log(uint8_t level, const char * func, uint32_t line, const char * restrict format, ...)
{
    if( level >= __LEVEL__ ) {
		char	str[64];
        va_list ap;
			
        snprintf(str, sizeof(str), "[%d]%s(%d):",level,func,line);
        simple_uart_putstring((const uint8_t *)str);
        
        va_start(ap, format);
        (void)vsnprintf(str, sizeof(str), format, ap);
        va_end(ap);
        
        simple_uart_putstring((const uint8_t *)str);
        simple_uart_putstring((const uint8_t *)"\r\n");
    }
}
