/**
 * @file     ble51822 board.c
 * @version  SDK:6.0.0;	SoftDevice:s110_nrf51822_7.0.0
 * @Compiler Armcc.exe v5.03.076(Evaluation) 
 * @IDE			 uVisionV4.72.0.0
 * @author	 Sam
 * @date     21/09/2015(First)
 * @brief   
 *
 **/
/* Includes*/
#include "bd_button.h"
#include "nrf_gpio.h"
#include "app_timer.h"
#include "ble_user_srv.h"
#include "bd_sensor_recive.h"
#include "app_util_platform.h"
#include <stddef.h>
#include "bd_uart_debug.h"
#include "nrf_delay.h"

static app_timer_id_t m_detect_timer_id;
static uint32_t m_detection_delay;
static button_event_callback_t bt_callback;

static uint8_t button_press_time;
static uint8_t button_release_time;
static bool bPressAction=false;
static bool bReleaseAction=true;

/**@brief Function for handling the timeout that delays reporting buttons as pushed.
 *
 * @details    The detect_timeout_handler(...) is a call-back issued from the app_timer
 *             module. It is called with the p_context parameter. The p_context parameter is
 *             provided to the app_timer module when a timer is started, using the call
 *             @ref app_timer_start. On @ref app_timer_start the p_context will be holding the
 *             currently pressed buttons.
 *
 * @param[in]  p_context   Pointer used for passing information app_start_timer() was called.
 *                         In the app_button module the p_context holds information on pressed
 *                         buttons.
 */
void detect_timeout_handler ( void* p_context)
{
	if(nrf_gpio_pin_read(BUTTON_POWER_PIN_NUMBER)==BUTTON_PRESS)
    {
		button_release_time=0;			
		if(button_press_time>250)
		{			
			if(bPressAction==false)
			{
				bt_callback(BUTTON_EVENT_SLEEP);
				bPressAction=true;
			}				
		}
		else
		{
			button_press_time++;
			if(button_press_time>10)
			{
				if(bReleaseAction==true)
				{
					bt_callback(BUTTON_EVENT_PRESS);
				}
				bReleaseAction=false;
			}
		}                    
    }
    else
    {
		button_press_time=0;
		if(button_release_time>10)
		{
			bPressAction=false;
			if(bReleaseAction==false)
			{
				bt_callback(BUTTON_EVENT_RELEASE);
				bReleaseAction=true;
			}
		}
		else
		{
			button_release_time++;
		}
    }
}
/* @brief battery init
  * @param  interval
  * @retval None
 */
void button_detect_timer_start(void)
{
    uint32_t err_code;
    // Start battery timer
    err_code = app_timer_start(m_detect_timer_id, m_detection_delay, NULL);
    APP_ERROR_CHECK(err_code);
}
/* @brief battery init
  * @param  interval
  * @retval None
 */
void button_detect_timer_stop(void)
{
    uint32_t err_code;
    // Stop battery timer
		err_code = app_timer_stop(m_detect_timer_id);
		APP_ERROR_CHECK(err_code);
}
/**
  * @brief 
  * @param 
  * @retval
  */
void button_init(uint32_t ticks_per_10ms, button_event_callback_t callback)
{
	uint32_t err_code;
	m_detection_delay=ticks_per_10ms;
	bt_callback=callback;
	
	nrf_gpio_cfg_input(BUTTON_POWER_PIN_NUMBER, NRF_GPIO_PIN_NOPULL);

  // Create battery timer
	err_code = app_timer_create(&m_detect_timer_id,
															APP_TIMER_MODE_REPEATED,
															detect_timeout_handler);
	APP_ERROR_CHECK(err_code);
}


/* Private functions */
