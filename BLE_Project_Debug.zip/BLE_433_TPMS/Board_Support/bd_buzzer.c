/**
 * @file     ble51822 board.c
 * @version  SDK:6.0.0;	SoftDevice:s110_nrf51822_7.0.0
 * @Compiler Armcc.exe v5.03.076(Evaluation) 
 * @IDE			 uVisionV4.72.0.0
 * @author	 sam
 * @date     21/09/2015(First)
 * @brief   
 *
 **/
/* Includes*/
#include "bd_buzzer.h"
#include <string.h>
#include "nordic_common.h"
#include "app_error.h"
#include "app_util.h"
#include "nrf_soc.h"
#include "bd_system_state_machine.h"


static app_timer_id_t m_buzzer_timer_id;
static uint32_t m_buzzer_delay;
static uint8_t bi_space_time;
static uint8_t none_space_time;
static uint8_t bi_times;
static uint8_t buzzer_run_time;
buzzer_status_t buzzer_state;
extern SYSTEM_TypeDef gSystem;
uint32_t final_config;


void BUZZER_ON(void)
{                                            
	*(uint32_t *)0x40009C0C = 1;					
	NRF_TIMER1->TASKS_START = 1;
}

void BUZZER_OFF(void)
{                                                         
	NRF_TIMER1->TASKS_STOP = 1;	 								
	*(uint32_t *)0x40009C0C = 0;
}
/**
  * @brief 
  * @param 
  * @retval
  */
static void buzzer_timeout_handler( void* p_context)
{
	if(bi_times)
	{
		buzzer_run_time++;
		if(buzzer_run_time<bi_space_time)
		{
			if(buzzer_state==BUZZER_STATE_OFF)
			{
				BUZZER_ON();
				buzzer_state=BUZZER_STATE_ON;
			}
		}
		else if(buzzer_run_time<none_space_time)
		{
			if(buzzer_state==BUZZER_STATE_ON)
			{
				buzzer_state=BUZZER_STATE_OFF;
				BUZZER_OFF();
				bi_times--;
			}			
		}
		else
		{
			buzzer_run_time=0;			
		}
	}
	else
	{	
		gSystem.sensor.bBuzzer_done=true;
	}
	if(gSystem.sensor.bBuzzer_done==true)
	{
		BUZZER_OFF();
		buzzer_run_time=0;
		bi_times=0;
		NRF_GPIOTE->CONFIG[0] = 0;
		nrf_gpio_cfg_output(BUZZER_PIN_NUMBER);	
	    nrf_gpio_pin_clear(BUZZER_PIN_NUMBER);
		app_timer_stop(m_buzzer_timer_id);
	}
}
/**
  * @brief 
  * @param  
  * @retval
  */
void buzzer_control(buzzer_model_t modle)
{
	if(modle==BUZZER_BI_ONCE)
	{
		bi_times=1;
		bi_space_time=3;
		none_space_time=bi_space_time+2;
	}
	else if(modle==BUZZER_BI_TWICE)
	{
		bi_times=1;
		bi_space_time=6;
		none_space_time=bi_space_time+2;
	}
	else if(modle==BUZZER_BI_ALARM)
	{
		bi_times=16;
		bi_space_time=4;
		none_space_time=bi_space_time+4;
	}

	if(modle!=BUZZER_INIT)
	{
		app_timer_stop(m_buzzer_timer_id);
		app_timer_start(m_buzzer_timer_id, m_buzzer_delay, NULL);
		buzzer_run_time=0;
		buzzer_state=BUZZER_STATE_OFF;
		NRF_GPIOTE->CONFIG[0] = final_config;
		gSystem.sensor.bBuzzer_done=false;
	}
	else
	{
		bi_times=0;
	}
}
/**
  * @brief 
  * @param 
  * @retval
  */
void buzzer_init(uint32_t ticks_per_100ms)
{
	nrf_gpio_cfg_output(BUZZER_PIN_NUMBER);	
	nrf_gpio_pin_clear(BUZZER_PIN_NUMBER);

	NRF_GPIOTE->CONFIG[0] |= (BUZZER_PIN_NUMBER << GPIOTE_CONFIG_PSEL_Pos)|
					 (GPIOTE_CONFIG_POLARITY_Toggle << GPIOTE_CONFIG_POLARITY_Pos)|
					 (GPIOTE_CONFIG_OUTINIT_Low << GPIOTE_CONFIG_OUTINIT_Pos);

	NRF_PPI->CH[0].EEP = (uint32_t)&NRF_TIMER1->EVENTS_COMPARE[0];
	NRF_PPI->CH[0].TEP = (uint32_t)&NRF_GPIOTE->TASKS_OUT[0];
	NRF_PPI->CHEN |= PPI_CHEN_CH0_Enabled<<PPI_CHEN_CH0_Pos;

	{
		final_config = NRF_GPIOTE->CONFIG[0] | GPIOTE_CONFIG_MODE_Task;
		/* Workaround for the OUTINIT PAN. When nrf_gpiote_task_config() is called a glitch happens
		on the GPIO if the GPIO in question is already assigned to GPIOTE and the pin is in the
		correct state in GPIOTE but not in the OUT register. */
		/* Configure channel to Pin31, not connected to the pin, and configure as a tasks that will set it to proper level */
		NRF_GPIOTE->CONFIG[0] = final_config | ((31 << GPIOTE_CONFIG_PSEL_Pos) & GPIOTE_CONFIG_PSEL_Msk);
		__NOP();
		__NOP();
		__NOP();
		NRF_GPIOTE->CONFIG[0] = final_config;
	}
		
    NRF_TIMER1->MODE      = TIMER_MODE_MODE_Timer;
    NRF_TIMER1->BITMODE   = TIMER_BITMODE_BITMODE_08Bit<< TIMER_BITMODE_BITMODE_Pos;
    NRF_TIMER1->PRESCALER = TIMER1_PRESCALER;//16MHz->	
    NRF_TIMER1->TASKS_CLEAR = 1;
    NRF_TIMER1->CC[0] = 186;//186uS		2.688KHz
	/*configure the shortcut to clear and restaart on compare0*/
	NRF_TIMER1->SHORTS = (TIMER_SHORTS_COMPARE0_CLEAR_Enabled << TIMER_SHORTS_COMPARE0_CLEAR_Pos);	
	*(uint32_t *)0x40009C0C = 0; 
	NRF_TIMER1->TASKS_START = 0;
	// Create battery timer 
	m_buzzer_delay=ticks_per_100ms;
	uint32_t err_code = app_timer_create(&m_buzzer_timer_id,
								APP_TIMER_MODE_REPEATED,
								buzzer_timeout_handler);
	APP_ERROR_CHECK(err_code);
}


